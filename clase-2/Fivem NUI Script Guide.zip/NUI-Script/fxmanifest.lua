fx_version 'cerulean'
game 'gta5'

name "__.seerrgiioo.__"
description "quasar university - leason 2"
author "__.seerrgiioo.__"
version "1.0.0"

lua54 'yes'

client_scripts {
	'client/*.lua'
}

files {
	'NUI/*.html',
	'NUI/**/*.css',
	'NUI/**/*.js'
}

ui_page 'NUI/index.html'