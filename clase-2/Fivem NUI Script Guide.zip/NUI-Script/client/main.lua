RegisterCommand('OpenNui', function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openNUI"
    })
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
end)