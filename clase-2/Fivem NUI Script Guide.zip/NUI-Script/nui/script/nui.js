document.addEventListener('DOMContentLoaded', () => {

    window.addEventListener('message', (event) => {
        const data = event.data;
        if (typeof data !== 'object' || !data.action) return;
    
        
        switch (data.action) {
            case 'openNUI':
                const openNUIButton = document.getElementById('open-nui');
                openNUIButton.style.display = 'block';
                break;
        }
    });
    
    // Get the elements
    const openNUIButton = document.getElementById('open-nui');
    const closeNUIButton = document.getElementById('close-nui');
    const nuiContainer = document.getElementById('nui-container');

    // Function to open the NUI
    openNUIButton.addEventListener('click', () => {
        nuiContainer.style.display = 'block';
    });

    // Function to close the NUI
    closeNUIButton.addEventListener('click', () => {
        nuiContainer.style.display = 'none';
        openNUIButton.style.display = 'none';
        fetch(`https://${GetParentResourceName()}/close`, { method: 'POST' });
    });
});

