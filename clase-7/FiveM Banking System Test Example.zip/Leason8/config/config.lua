Config = Config or {}
Locales = Locales or {}
Config.Framework = 'esx' -- Change to 'qbcore' if using QBCore
Config.Locale = 'en' -- Default language ('en')

function _U(key)
    return Locales[Config.Locale][key] or key
end