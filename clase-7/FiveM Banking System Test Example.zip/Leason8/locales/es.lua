Locales['es'] = {
    ['deposit_success'] = '¡Depósito exitoso!',
    ['withdraw_success'] = '¡Retiro exitoso!',
    ['transfer_success'] = '¡Transferencia exitosa!',
    ['invalid_amount'] = 'Cantidad no válida ingresada.',
    ['error_retrieve'] = 'Error: No se pudieron obtener los detalles bancarios.'
}