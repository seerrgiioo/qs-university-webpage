Locales['en'] = {
    ['deposit_success'] = 'Deposit successful!',
    ['withdraw_success'] = 'Withdrawal successful!',
    ['transfer_success'] = 'Transfer successful!',
    ['invalid_amount'] = 'Invalid amount entered.',
    ['error_retrieve'] = 'Error: Unable to retrieve bank details.'
}