local Framework = nil
local FrameworkName = Config.Framework

Citizen.CreateThread(function()
    if FrameworkName == 'esx' then
        Framework = exports['es_extended']:getSharedObject()
    elseif FrameworkName == 'qbcore' then
        Framework = exports['qb-core']:GetCoreObject()
    else
        print('Error: Unsupported framework specified in config.')
    end
end)

RegisterCommand('bank', function()
    if FrameworkName == 'esx' then
        Framework.TriggerServerCallback('bank:getBalance', function(balance, cash)
            if balance and cash then
                TriggerEvent('bank:client:openMenu', balance, cash)
            else
                print('Error: Unable to retrieve balance.')
            end
        end)
    elseif FrameworkName == 'qbcore' then
        Framework.Functions.TriggerCallback('bank:getBalance', function(balance, cash)
            if balance and cash then
                TriggerEvent('bank:client:openMenu', balance, cash)
            else
                print('Error: Unable to retrieve balance.')
            end
        end)
    else
        print('Error: Unsupported framework specified in config.')
    end
end)

RegisterNetEvent('bank:client:openMenu')
AddEventHandler('bank:client:openMenu', function(balance, cash)
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'openMenu',
        balance = balance,
        cash = cash
    })
end)

RegisterNUICallback('deposit', function(data, cb)
    local amount = tonumber(data.amount)
    if amount and amount > 0 then
        TriggerServerEvent('bank:server:deposit', amount)
        cb('ok')
    else
        cb('error')
    end
end)

RegisterNUICallback('withdraw', function(data, cb)
    local amount = tonumber(data.amount)
    if amount and amount > 0 then
        TriggerServerEvent('bank:server:withdraw', amount)
        cb('ok')
    else
        cb('error')
    end
end)

RegisterNUICallback('transfer', function(data, cb)
    local targetId = tonumber(data.targetId)
    local amount = tonumber(data.amount)
    if targetId and amount and amount > 0 then
        TriggerServerEvent('bank:server:transfer', targetId, amount)
        cb('ok')
    else
        cb('error')
    end
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNetEvent('bank:client:notify')
AddEventHandler('bank:client:notify', function(messageKey)
    local message = _U(messageKey)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(message)
    DrawNotification(false, true)
end)
