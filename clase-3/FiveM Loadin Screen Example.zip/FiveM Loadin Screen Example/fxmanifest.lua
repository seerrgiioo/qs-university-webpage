fx_version 'bodacious'
game 'gta5'

name "__.seerrgiioo.__"
description "quasar university - leason 3"
author "__.seerrgiioo.__"
version "1.0.0"

files {
    'html/index.html',
    'html/style.css',
    'html/bankgothic.ttf',
    'html/background.webp'
}

loadscreen 'html/index.html'

loadscreen_cursor 'yes'


