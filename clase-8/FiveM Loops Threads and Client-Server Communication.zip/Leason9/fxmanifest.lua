fx_version 'bodacious'
game 'gta5'

name "__.seerrgiioo.__"
description "quasar university - leason 9"
author "__.seerrgiioo.__"
version "1.0.0"

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

shared_scripts {
    'config.lua'
}
