
local Framework = nil
local FrameworkName = Config.Framework
local isActive = false

Citizen.CreateThread(function()
    if FrameworkName == 'esx' then
        Framework = exports['es_extended']:getSharedObject()
    elseif FrameworkName == 'qbcore' then
        Framework = exports['qb-core']:GetCoreObject()
    else
        print('Error: Unsupported framework specified in config.')
    end
end)

RegisterCommand('toggleloop', function()
    isActive = not isActive
    print("Loop is now " .. (isActive and "active" or "inactive"))
end)

Citizen.CreateThread(function()
    while true do
        if isActive then
            print("The loop is running.")
        end
        Citizen.Wait(1000)
    end
end)

RegisterCommand('sendmessage', function(_, args)
    local message = table.concat(args, " ")
    if message ~= "" then
        TriggerServerEvent('example:server:receiveMessage', message)
    else
        print("Please provide a message to send.")
    end
end)

RegisterNetEvent('example:client:receiveResponse')
AddEventHandler('example:client:receiveResponse', function(response)
    print("Response from server: " .. response)
end)

Citizen.CreateThread(function()
    local countdown = 30
    while countdown > 0 do
        print("Time remaining: " .. countdown .. " seconds")
        Citizen.Wait(1000)
        countdown = countdown - 1
    end
    print("Countdown finished!")
end)
