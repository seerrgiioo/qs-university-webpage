
Config = Config or {}
Config.Framework = 'esx' -- Change to 'qbcore' for QBCore framework
