
if Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'qbcore' then
    QBCore = exports['qb-core']:GetCoreObject()
else
    print('Error: Unsupported framework specified in config.')
end

RegisterNetEvent('example:server:receiveMessage')
AddEventHandler('example:server:receiveMessage', function(message)
    print("Received message from client: " .. message)
    TriggerClientEvent('example:client:receiveResponse', source, "Message received: " .. message)
end)

if Config.Framework == 'esx' then
    ESX.RegisterServerCallback('example:server:getBalance', function(source, cb)
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            local balance = xPlayer.getAccount('bank').money
            local cash = xPlayer.getMoney()
            cb(balance, cash)
        else
            cb(0, 0)
        end
    end)
elseif Config.Framework == 'qbcore' then
    QBCore.Functions.CreateCallback('example:server:getBalance', function(source, cb)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if xPlayer then
            local balance = xPlayer.Functions.GetMoney('bank')
            local cash = xPlayer.Functions.GetMoney('cash')
            cb(balance, cash)
        else
            cb(0, 0)
        end
    end)
end
