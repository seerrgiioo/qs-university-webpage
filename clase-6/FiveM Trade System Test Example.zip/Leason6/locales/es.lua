Locales['es'] = {
    ['usage_trade_request'] = "Uso: /tradeRequest [targetId] [itemName] [itemCount]",
    ['trade_request_sent'] = "Solicitud de intercambio enviada al jugador con ID: %s.",
    ['trade_success'] = "¡Intercambio completado con éxito!",
    ['trade_failed'] = "El intercambio falló. Verifica la disponibilidad del artículo.",
    ['trade_received'] = "Has recibido un artículo de un intercambio."
}