Locales['en'] = {
    usage_trade_request = "Usage: /tradeRequest [targetId] [itemName] [itemCount]",
    trade_request_sent = "Trade request sent to Player ID: %s.",
    trade_success = "Trade completed successfully!",
    trade_failed = "Trade failed. Check item availability.",
    trade_received = "You received an item from a trade."
}
