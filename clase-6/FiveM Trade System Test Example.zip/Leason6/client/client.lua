
RegisterNetEvent('trade:client:receiveRequest')
AddEventHandler('trade:client:receiveRequest', function(requesterId, itemName, itemCount)
    TriggerEvent('trade:client:showMenu', requesterId, itemName, itemCount)
end)

RegisterNetEvent('trade:client:showMenu')
AddEventHandler('trade:client:showMenu', function(requesterId, itemName, itemCount)
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'showMenu',
        requesterId = requesterId,
        itemName = itemName,
        itemCount = itemCount
    })
end)

RegisterNetEvent('trade:client:notify')
AddEventHandler('trade:client:notify', function(message)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(message)
    DrawNotification(false, true)
end)

RegisterNUICallback('acceptRequest', function(data, cb)
    TriggerServerEvent('trade:server:confirmTrade', data.playerId, data.itemName, data.itemCount)
    cb({ success = true })
    SetNuiFocus(false, false)
end)