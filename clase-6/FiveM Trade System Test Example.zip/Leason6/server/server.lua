Core = {}
PlayerTrades = {}

RegisterCommand('tradeRequest', function(source, args)
    local targetId = tonumber(args[1])
    local itemName = args[2]
    local itemCount = tonumber(args[3])

    if not targetId or not itemName or not itemCount or itemCount <= 0 then
        TriggerClientEvent('trade:client:notify', source, _U('usage_trade_request'))
        return
    end

    TriggerClientEvent('trade:client:receiveRequest', targetId, source, itemName, itemCount)
    TriggerClientEvent('trade:client:notify', source, string.format(_U('trade_request_sent'), targetId))
end)

RegisterNetEvent('trade:server:confirmTrade')
AddEventHandler('trade:server:confirmTrade', function(sourcePlayer, itemName, itemCount)
    local source = source
    local targetPlayer = sourcePlayer

    if HasItem(targetPlayer, itemName, itemCount) then
        RemoveItem(targetPlayer, itemName, itemCount)
        GiveItem(source, itemName, itemCount)
        TriggerClientEvent('trade:client:notify', targetPlayer, _U('trade_success'))
        TriggerClientEvent('trade:client:notify', source, _U('trade_received'))
    else
        TriggerClientEvent('trade:client:notify', source, _U('trade_failed'))
    end
end)

if Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
end

function HasItem(playerId, itemName, itemCount)
    local playerId = tonumber(playerId) -- Convert playerId
    local itemCount = tonumber(itemCount) -- Convert itemCount
    if not playerId or not itemName or not itemCount or itemCount <= 0 then
        return false
    end

    if Config.Inventory == 'qs' then 
        local totalAmount = exports['qs-inventory']:GetItemTotalAmount(playerId, itemName)
        return totalAmount >= itemCount
    elseif Config.Inventory == 'ox' then
        local itemCountOX = exports.ox_inventory:GetItemCount(playerId, itemName)
        return itemCountOX >= itemCount
    elseif Config.Inventory == 'esx' then
        local player = ESX.GetPlayerFromId(playerId)
        local item = player.getInventoryItem(itemName)
        return item and item.count >= itemCount
    elseif Config.Inventory == 'qb' then
        local player = QBCore.Functions.GetPlayer(playerId)
        local item = player.Functions.GetItemByName(itemName)
        return item and item.amount >= itemCount
    else
        return false
    end
end

function RemoveItem(playerId, itemName, itemCount)
    if Config.Inventory == 'qs' then
        exports['qs-inventory']:RemoveItem(playerId, itemName, itemCount)
    elseif Config.Inventory == 'ox' then
        exports.ox_inventory:RemoveItem(playerId, itemName, itemCount)
    elseif Config.Inventory == 'esx' then
        local player = ESX.GetPlayerFromId(playerId)
        player.removeInventoryItem(itemName, itemCount)
    elseif Config.Inventory == 'qb' then
        local player = QBCore.Functions.GetPlayer(playerId)
        player.Functions.RemoveItem(itemName, itemCount)
    end
end

function GiveItem(playerId, itemName, itemCount)
    if Config.Inventory == 'qs' then
        exports['qs-inventory']:AddItem(playerId, itemName, itemCount)
    elseif Config.Inventory == 'ox' then
        exports.ox_inventory:AddItem(playerId, itemName, itemCount)
    elseif Config.Inventory == 'esx' then
        local player = ESX.GetPlayerFromId(playerId)
        player.addInventoryItem(itemName, itemCount)
    elseif Config.Inventory == 'qb' then
        local player = QBCore.Functions.GetPlayer(playerId)
        player.Functions.AddItem(itemName, itemCount)
    end
end

function _U(str)
    if Locales and Locales[Config.Locale] and Locales[Config.Locale][str] then
        return Locales[Config.Locale][str]
    else
        return str
    end
end
