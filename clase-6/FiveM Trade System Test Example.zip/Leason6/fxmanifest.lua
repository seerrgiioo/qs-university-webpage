fx_version 'bodacious'
game 'gta5'

name "__.seerrgiioo.__"
description "quasar university - leason 7"
author "__.seerrgiioo.__"
version "1.0.0"

client_scripts {
    'client/*.lua'
}

server_scripts {
    'server/*.lua'
}

shared_scripts {
    'config/*.lua',
    'locales/*.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/js/index.js',
    'html/css/index.css',
}