window.addEventListener('message', (event) => {
    const data = event.data;
    if (typeof data !== 'object' || !data.action) return;

    switch (data.action) {
        case 'showMenu':
            ShowRequestEventMenu(data.requesterId, data.itemName, data.itemCount);
            break;
    }
});

function ShowRequestEventMenu(requesterId, itemName, itemCount) {
    const menu = document.getElementById('RequestTradeMenu');
    menu.style.display = 'block';

    const playerIdInput = document.getElementById('RequestTradeMenuPlayerId');
    const itemNameInput = document.getElementById('RequestTradeMenuItemName');
    const itemCountInput = document.getElementById('RequestTradeMenuItemCount');

    // Rellenar los campos con los datos recibidos
    playerIdInput.value = requesterId;
    itemNameInput.value = itemName;
    itemCountInput.value = itemCount;

    // Deshabilitar los campos para evitar modificaciones accidentales
    playerIdInput.disabled = true;
    itemNameInput.disabled = true;
    itemCountInput.disabled = true;
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('AcceptTradeButton').addEventListener('click', () => {
        const playerId = document.getElementById('RequestTradeMenuPlayerId').value;
        const itemName = document.getElementById('RequestTradeMenuItemName').value;
        const itemCount = document.getElementById('RequestTradeMenuItemCount').value;

        // Enviar la solicitud al servidor para aceptar la solicitud de intercambio
        fetch(`http://${GetParentResourceName()}/acceptRequest`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ playerId, itemName, itemCount })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.getElementById('RequestTradeMenu').style.display = 'none';
            } else {
                console.error('Trade request failed:', data.message);
            }
        })

    });
});