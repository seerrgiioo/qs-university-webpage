Config = Config or {}
Locales = Locales or {}

Config.Locale = 'en'

Config.Inventory = 'qs' -- 'esx', 'ox', 'qs', 'qb'

Config.Framework = 'esx' -- 'esx', 'qb'